# Script Auto Installer by Indoworx
# www.indoworx.com
while :
  do 
  userlimit 1
  sleep 20
  done
#while :
  #do
  #./userlimit.sh 2
  #sleep 55 
  #done
#while :
  #do
  #%./userexpired.sh
  #%sleep 36000
  #done
