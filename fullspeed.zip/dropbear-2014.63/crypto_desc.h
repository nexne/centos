#ifndef _CRYPTO_DESC_H
#define _CRYPTO_DESC_H

void crypto_init();

extern int dropbear_ltc_prng;

#endif /* _CRYPTO_DESC_H */

